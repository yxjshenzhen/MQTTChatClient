package com.you.im.main;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {
	
	static MqttExecute mqttExecute = new MqttExecute();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome use YXJ's IM Client!\n");
		
		// ����Լ������
		Runnable input = new Runnable() {
			public void run() {
				while(true){
					mqttExecute.read("ImClients");
				}
				
			}
		};
		Thread thread1 = new Thread(input);
		thread1.start();

		// ����Լ������
		Runnable output = new Runnable() {
			public void run() {
				System.out.println("�������������(�س���ȷ��)");
				Scanner in = new Scanner(System.in);
				String name = in.next();
				System.out.println("��������ģʽ������������>");
				while (in.hasNext()) {
					String msg = in.next();
					   
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					   
					mqttExecute.write("ImClients",name+":"+msg+"<"+formatter.format(new Date()));
					
				}
			}
		};
		Thread thread2 = new Thread(output);
		thread2.start();

	}
}
