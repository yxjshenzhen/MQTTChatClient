package com.you.im.main;

import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.fusesource.mqtt.client.BlockingConnection;
import org.fusesource.mqtt.client.MQTT;
import org.fusesource.mqtt.client.Message;
import org.fusesource.mqtt.client.QoS;
import org.fusesource.mqtt.client.Topic;

/**
 * 
 * 
 * 
 * 
 * MQTT moquette 的Server 段用于发布主题，并发布主题信息
 * 
 * 采用阻塞式 发布主题
 * 
 * @author You
 */
public class MqttExecute {
//	private static final Logger LOG = LoggerFactory.getLogger(MqttExecute.class);

	private final static String CONNECTION_STRING = "tcp://115.28.236.237:1883";
	private final static boolean CLEAN_START = true;
	private final static short KEEP_ALIVE = 60;// 低耗网络，但是又需要及时获取数据，心跳30s

	public final static long RECONNECTION_ATTEMPT_MAX = 6;
	public final static long RECONNECTION_DELAY = 2000;

	public final static int SEND_BUFFER_SIZE = 2 * 1024 * 1024;// 发送最大缓冲为2M


	public void write(String topic, String exeStr) {
		MQTT mqtt = new MQTT();
		try {
			// 设置服务端的ip
			mqtt.setHost(CONNECTION_STRING);
			// 连接前清空会话信息
			mqtt.setCleanSession(CLEAN_START);
			// 设置重新连接的次数
			mqtt.setReconnectAttemptsMax(RECONNECTION_ATTEMPT_MAX);
			// 设置重连的间隔时间
			mqtt.setReconnectDelay(RECONNECTION_DELAY);
			// 设置心跳时间
			mqtt.setKeepAlive(KEEP_ALIVE);
			// 设置缓冲的大小
			mqtt.setSendBufferSize(SEND_BUFFER_SIZE);
			// mqtt.setClientId("aa");

			// 创建连接
			BlockingConnection connection = mqtt.blockingConnection();
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
			// 开始连接
			connection.connect();
			try {

				// 保证设备订阅到的是用户最后一次操作指令，retained设置为true
				connection.publish(topic, exeStr.getBytes(), QoS.AT_MOST_ONCE,
						false);

//				LOG.info("MQTTServer Message  Topic=" + topic + "  Content :"
//						+ exeStr.toString() + "   发送数据时间："
//						+ df.format(new Date()));
				// 关闭连接，不然就是长链接，消耗服务器资源（减少了可连接数）
				connection.disconnect();

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void read(String topic) {
		MQTT mqtt = new MQTT();
		
		
		// 设置服务端的ip
		try {
			mqtt.setHost(CONNECTION_STRING);

			// 连接前清空会话信息
			mqtt.setCleanSession(CLEAN_START);
			// 设置重新连接的次数
			mqtt.setReconnectAttemptsMax(RECONNECTION_ATTEMPT_MAX);
			// 设置重连的间隔时间
			mqtt.setReconnectDelay(RECONNECTION_DELAY);
			// 设置心跳时间
			mqtt.setKeepAlive(KEEP_ALIVE);
			// 设置缓冲的大小
			mqtt.setSendBufferSize(SEND_BUFFER_SIZE);

			BlockingConnection connection = mqtt.blockingConnection();
			connection.connect();

			Topic[] topics = { new Topic(topic, QoS.AT_LEAST_ONCE) };
			connection.subscribe(topics);
			
			try {
//				while (true) {
					Message message = connection.receive();
					//String msg = String.valueOf(message.getPayloadBuffer());
					
					String str1 = new String(message.getPayload());
					String str[] = str1.split("<");
					System.out.println(str[1]);
					System.out.println(str[0]/*str[1]+"说："+str[2]*/);
					
					String str2[] = str[0].split("\"");
					
					//定义关机命令
					String cmd = "shutdown-s-t";
					if(str[0].contains(cmd)){
						String regEx="[^0-9]";   
						Pattern p = Pattern.compile(regEx);   
						Matcher m = p.matcher(str[0]);   
						System.out.println(m.replaceAll("").trim());
						Runtime rt1 = Runtime.getRuntime();
						rt1.exec("shutdown -s -t "+Integer.parseInt(m.replaceAll("").trim())+" -c "+str2[1]+" -f");
					}else if(str[0].contains("cancelshutdown")){
						Runtime rt2 = Runtime.getRuntime();
						rt2.exec("shutdown -a");
					}
					
					message.ack();
					
//				}
					
			} finally {
				connection.disconnect();
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	}
